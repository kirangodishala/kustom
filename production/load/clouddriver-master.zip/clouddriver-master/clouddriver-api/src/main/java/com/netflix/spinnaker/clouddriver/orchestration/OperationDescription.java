package com.netflix.spinnaker.clouddriver.orchestration;

/** Marker interface for inputs to an {@link AtomicOperation}. */
public interface OperationDescription {}
